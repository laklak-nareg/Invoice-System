import { Injectable } from '@nestjs/common';
import { EventPattern } from '@nestjs/microservices';
import * as nodemailer from 'nodemailer';

@Injectable()
export class EmailSenderService {
  private transporter: nodemailer.Transporter;

  constructor() {
    this.transporter = nodemailer.createTransport({
      service: 'Gmail',
      auth: {
        user: 'testforpayever29@gmail.com',
        pass: 'TFP_!testForPayever29',
      },
    });
  }

  @EventPattern('daily_sales_report')
  async handleDailySalesReport(report: any) {
    console.log('Received Sales Report:', report);

    const mailOptions = {
      from: 'testforpayever29@gmail.com',
      to: 'nareglaklakian@gmail.com',
      subject: 'Daily Sales Report',
      text: `Here is the daily sales report:\n\nTotal Sales: ${report.totalSales}\n\nItem Summary:\n${Object.entries(
        report.itemSummary,
      )
        .map(([sku, qt]) => `${sku}: ${qt}`)
        .join('\n')}`,
    };

    try {
      await this.transporter.sendMail(mailOptions);
      console.log('Email sent successfully');
    } catch (error) {
      console.error('Error sending email:', error);
    }
  }
}
